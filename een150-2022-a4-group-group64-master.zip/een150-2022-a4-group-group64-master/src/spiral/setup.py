from setuptools import setup

package_name = 'spiral'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='elm4n',
    maintainer_email='elmer.janmark@gmail.com',
    description='spiral shit',
    license='Apache License 2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'spiral = spiral.spiral:main',
            'sub_spiral = spiral.sub_spiral:main',
        ],
    },
)
