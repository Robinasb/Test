# Xacro (XML Macros)

**Xacro is an XML macro language**

With Xacro, you can construct shorter and more readable XML files by using macros that expand to larger XML expressions.
Documentation can be found in the wiki: http://wiki.ros.org/xacro
