from predicates.state import State
from predicates import guards, actions

if __name__ == '__main__':
    # run in terminal when venv is sourced: python3 -m planner
    pass

