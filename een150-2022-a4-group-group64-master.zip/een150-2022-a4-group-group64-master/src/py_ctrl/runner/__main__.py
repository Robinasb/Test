import runner.ctrl

if __name__ == '__main__':
    # run in terminal when venv is sourced: python3 -m runner
    runner.ctrl.run()

